package model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aluno
 */
public class Cliente {
    String nome;
    String cpf, telefone;
    int idade;
    private String valor;
    
    public Cliente (String nome, String cpf, String telefone, int idade){
      this.nome = nome;
      this.telefone = telefone;
      this.cpf = cpf;
      this.idade = idade;
    }
    
    
    float calcValor (int idade){
        float valor = 0.0f;
        
        if(idade<=10){
            valor = 30.00f;
        }else if (idade<10 && idade>=29){
            valor = 60.00f;
        } else if (idade>29 && idade<=45){
            valor = 120.00f;
        } else if (idade>45 && idade<=59){
            valor = 150.00f;
        }
        
        return valor;
        
    }
    
    public String toString() {
        return "Cliente{" + "nome =" + this.nome + ", cpf =" + this.cpf + ", telefone =" + this.telefone + ", idade =" + this.idade + "}"  
        + "\n Taxa = R$ " + this.valor;
    }

}

